package entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Table(name="Address")
@Entity
public class Address {

	private String state;
	private String city;
	private String locationname;
	private String houseno;
	
	public Address() {
		
	}
	
	public Address(String state, String city, String locationname, String houseno) {
		super();
		this.state = state;
		this.city = city;
		this.locationname = locationname;
		this.houseno = houseno;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLocationname() {
		return locationname;
	}
	public void setLocationname(String locationname) {
		this.locationname = locationname;
	}
	public String getHouseno() {
		return houseno;
	}
	public void setHouseno(String houseno) {
		this.houseno = houseno;
	}
	@Override
	public String toString() {
		return "Address [state=" + state + ", city=" + city + ", locationname=" + locationname + ", houseno=" + houseno
				+ "]";
	}
	
	
	
}
