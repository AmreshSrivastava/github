package entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="Delivery")
public class Delivery {

	private String deliveryid;
	private String name;
	private String email;
	private String mobno;
	private Address address;
	private double price;
	
	public Delivery() {
		
	}

	public Delivery(String deliveryid, String name, String email, String mobno, Address address, double price) {
		super();
		this.deliveryid = deliveryid;
		this.name = name;
		this.email = email;
		this.mobno = mobno;
		this.address = address;
		this.price = price;
	}

	public String getDeliveryid() {
		return deliveryid;
	}

	public void setDeliveryid(String deliveryid) {
		this.deliveryid = deliveryid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobno() {
		return mobno;
	}

	public void setMobno(String mobno) {
		this.mobno = mobno;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Delivery [deliveryid=" + deliveryid + ", name=" + name + ", email=" + email + ", mobno=" + mobno
				+ ", address=" + address + ", price=" + price + "]";
	}
	
	
}
