package entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Table(name="User")
@Entity
public class User {

	private String firstname;
	private String lastname;
	private String email;
	private String mobno;
	private String password;
	private Address address;
	private String role;
	private String gender;
	private String age;
	
	public User() {
		
	}

	public User(String firstname, String lastname, String email, String mobno, String password, Address address,
			String role, String gender, String age) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.mobno = mobno;
		this.password = password;
		this.address = address;
		this.role = role;
		this.gender = gender;
		this.age = age;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobno() {
		return mobno;
	}

	public void setMobno(String mobno) {
		this.mobno = mobno;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "User [firstname=" + firstname + ", lastname=" + lastname + ", email=" + email + ", mobno=" + mobno
				+ ", password=" + password + ", address=" + address + ", role=" + role + ", gender=" + gender + ", age="
				+ age + "]";
	}
	
	
	
}
