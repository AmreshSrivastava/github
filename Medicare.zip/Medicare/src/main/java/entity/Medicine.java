package entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Table(name="Medicine")
@Entity
public class Medicine {

	private String id;
	private String medname;
	private String company;
	private String offer;
	private String price;
	
	public Medicine() {
		
	}

	public Medicine(String id, String medname, String company, String offer, String price) {
		super();
		this.id = id;
		this.medname = medname;
		this.company = company;
		this.offer = offer;
		this.price = price;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMedname() {
		return medname;
	}

	public void setMedname(String medname) {
		this.medname = medname;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}


	public String getOffer() {
		return offer;
	}

	public void setOffer(String offer) {
		this.offer = offer;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Medicine [id=" + id + ", medname=" + medname + ", company=" + company + 
				 ", offer=" + offer + ", price=" + price + "]";
	}
	
	
	
}
