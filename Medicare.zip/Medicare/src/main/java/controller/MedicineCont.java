package controller;

import org.springframework.stereotype.Controller;

@Controller
public class MedicineCont {

}
