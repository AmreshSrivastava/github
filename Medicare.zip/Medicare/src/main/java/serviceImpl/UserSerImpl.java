package serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import entity.Address;
import entity.Medicine;
import entity.User;
import exception.CityNotFoundException;
import exception.CompanyNotFoundException;
import exception.UserNotFoundException;
import repository.UserRepo;
import service.UserSer;

@Service("UserService")
public class UserSerImpl implements UserSer {

	private UserRepo userrepo;
	private UserSer userser;
	
	
	public UserSerImpl(UserRepo userrepo, UserSer userser) {
		super();
		this.userrepo = userrepo;
		this.userser = userser;
	}

	@Override
	public User insert(String firstname, String lastname, String email, String mobno, String password, String address,
			String role, String gender, String age) {
		
		User u =new User();
		u.setFirstname("john");
		u.setLastname("doe");
		u.setEmail("john@gmail.com");
		u.setMobno("456123789");
		u.setPassword("456789123");
		u.setRole("user");
		u.setAge("47");
		
		User u1 = userrepo.save(u);
		return u1;
	}

	@Override
	public void update(String firstname, String lastname, String email, String mobno, String password, String address,
			String role, String gender, String age) {
		User u =new User();
		u.setFirstname("john");
		u.setLastname("doe");
		u.setEmail("john@gmail.com");
		u.setMobno("456123789");
		u.setPassword("456789123");
		u.setRole("user");
		u.setAge("47");
		
		User u1 = userrepo.save(u);
		
	}

	@Override
	public void delete(String mobno) {
		
		userrepo.deleteByMobno(mobno);
		
	}

	@Override
	public List<User> getUser() {
		
		return userrepo.findAll();
	}

	@Override
	public User getUser(String mobno, String email) throws UserNotFoundException {
		User us = null;
		Optional <User> usOptional =  userrepo.findbyCompany(mobno,email);
		if(usOptional.isPresent()) {
			us=usOptional.get();
		}
		else
		{
			throw new UserNotFoundException("User not found");
		}
		return us;
	}

	@Override
	public User findAllUserByCity(String city) throws CityNotFoundException{
		User us1 = null;
		Optional <User> userOptional =  userrepo.findAllByCity(city);
		if(userOptional.isPresent()) {
			us1=userOptional.get();
		}
		else
		{
			throw new CityNotFoundException("City not found");
		}
		return us1;
	}

}
