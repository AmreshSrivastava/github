package serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import entity.Address;
import entity.Delivery;
import exception.DeliveryNotFoundException;
import repository.DeliveryRepo;
import service.DeliverySer;

@Service
public class DeliverySerImpl implements DeliverySer {

	private DeliveryRepo delrepo;
	private DeliverySer delser;
	
	
	public DeliverySerImpl(DeliveryRepo delrepo, DeliverySer delser) {
		super();
		this.delrepo = delrepo;
		this.delser = delser;
	}

	@Override
	public Delivery insert(String deliveryid, String name, String email, String mobno,
			Address address, double price) {
		
		Delivery d = new Delivery();
		d.setDeliveryid("1542");
		d.setName("john");
		d.setEmail("john@gmail.com");
		d.setMobno("457812693");
		d.setAddress(address);
		d.setPrice(4512);
		
		Delivery d1 = delrepo.save(d);
		return d1;
	}

	@Override
	public void update(String deliveryid, String name, String email, String mobno, 
			Address address, double price) {
		
		Delivery d = new Delivery();
		d.setDeliveryid("1542");
		d.setName("john");
		d.setEmail("john@gmail.com");
		d.setMobno("457812693");
		d.setAddress(address);
		d.setPrice(4512);
		
		Delivery d1 = delrepo.save(d);
		
	}

	@Override
	public void delete(String deliveryid) {
		
		delrepo.deleteByDeliveryid(deliveryid);
		
	}

	@Override
	public List<Delivery> getDelivery() {
		
		return delrepo.findAll();
	}

	@Override
	public Delivery getDelivery(String city) throws  DeliveryNotFoundException{
		Delivery dl = null;
		Optional <Delivery> dlOptional =  delrepo.findbyCity(city);
		if(dlOptional.isPresent()) {
			dl=dlOptional.get();
		}
		else
		{
			throw new DeliveryNotFoundException("Delivery not found");
		}
		return dl;

     }
}
