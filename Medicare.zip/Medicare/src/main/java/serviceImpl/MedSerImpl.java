package serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import entity.Medicine;
import exception.CompanyNotFoundException;
import repository.MedicineRepo;
import service.MedicineSer;

@Service
public class MedSerImpl implements MedicineSer {

	private MedicineRepo medrepo;
	private MedicineSer medser;
	
	
	public MedSerImpl(MedicineRepo medrepo, MedicineSer medser) {
		super();
		this.medrepo = medrepo;
		this.medser = medser;
	}


	@Override
	public Medicine insert(String id, String medname, String company,
			String description, String offer, String price) {
		Medicine m = new Medicine();
		m.setId("123");
		m.setMedname("crocin");
		m.setCompany("crocin ltd");
		m.setOffer("5%");
		m.setPrice("150");  //packet price
		
		Medicine m1 = medrepo.save(m);
		return m1;
	}


	@Override
	public void update(String id, String medname, String company,
			String description, String offer, String price) {
		
		Medicine m = new Medicine();
		m.setId("123");
		m.setMedname("crocin");
		m.setCompany("crocin ltd");
		m.setOffer("5%");
		m.setPrice("150");  //packet price
		
		Medicine m1 = medrepo.save(m);
		
		
	}


	@Override
	public void delete(String id, String medname) {
		
		medrepo.deleteByIdAndMedname(id,medname);
		
	}


	@Override
	public List<Medicine> getMedicine() {
		
		return medrepo.findAll();
	}


	@Override
	public Medicine getMedicine(String company) throws CompanyNotFoundException{
		Medicine md = null;
		Optional <Medicine> mdOptional =  medrepo.findbyCompany(company);
		if(mdOptional.isPresent()) {
			md=mdOptional.get();
		}
		else
		{
			throw new CompanyNotFoundException("Company not found");
		}
		return md;
	
	}

}
