package service;

import java.util.List;

import org.springframework.stereotype.Component;

import entity.User;
import exception.CityNotFoundException;
import exception.UserNotFoundException;

@Component
public interface UserSer {

	//crud operation 
	
	User insert(String firstname , String lastname , String email , 
			String mobno , String password ,String address , String role
			, String gender , String age);
	
	void update(String firstname , String lastname , String email , 
			String mobno , String password ,String address , String role
			, String gender , String age);
	
	void delete(String mobno);
	
	List <User> getUser();
	
	User getUser(String mobno , String email) throws UserNotFoundException;
	
	User findAllUserByCity(String city) throws CityNotFoundException;
}
