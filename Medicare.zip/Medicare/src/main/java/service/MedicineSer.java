package service;

import java.util.List;

import org.springframework.stereotype.Component;

import entity.Medicine;
import entity.User;
import exception.CompanyNotFoundException;

@Component
public interface MedicineSer {

	//crud operation
	
	Medicine insert(String id , String medname , String company , String description , 
			String offer , String price);
	
	void update(String id , String medname , String company , String description , 
			String offer , String price);
	
	void delete(String id , String medname);
	
	List <Medicine> getMedicine();
	
	Medicine getMedicine(String company ) throws CompanyNotFoundException;
	
	
	
}
