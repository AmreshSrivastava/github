package service;


import java.util.List;

import entity.Address;
import entity.Delivery;
import exception.DeliveryNotFoundException;

public interface DeliverySer {

	Delivery insert(String deliveryid, String name, String email, String mobno,
			Address address,double price );
	
	void update(String deliveryid, String name, String email, String mobno,
			Address address,double price );
	
	void delete(String deliveryid);
	
    List <Delivery> getDelivery();
	
	Delivery getDelivery(String city ) throws DeliveryNotFoundException;
	
}
