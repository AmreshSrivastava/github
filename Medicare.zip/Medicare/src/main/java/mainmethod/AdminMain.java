package mainmethod;

import entity.Admin;

public class AdminMain {

	public static void main(String[] args) {
		
		Admin ad1 = new Admin();
		
		ad1.setName("Amresh");
		ad1.setEmail("amresh@gmail.com");
		ad1.setMobno("456123789");
		ad1.setPassword("4561236");
		ad1.setRole("Admin");
		
		System.out.println(ad1);

	}

}
