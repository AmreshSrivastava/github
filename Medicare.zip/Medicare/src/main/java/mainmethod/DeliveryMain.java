package mainmethod;

public class DeliveryMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
