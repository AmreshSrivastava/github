package mainmethod;

import entity.Address;

public class AddressMain {

	public static void main(String[] args) {

		Address a1 = new Address();
		
		a1.setState("UP");
		a1.setCity("Prayagraj");
		a1.setLocationname("Civil line");
		a1.setHouseno("A45");
		
		
		System.out.println(a1);


	}

}
