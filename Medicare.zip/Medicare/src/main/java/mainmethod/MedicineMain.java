package mainmethod;

import entity.Medicine;

public class MedicineMain {

	public static void main(String[] args) {
		
		Medicine md1 = new Medicine();
		
		md1.setId("1");
		md1.setMedname("Crocin");
		md1.setCompany("crocin private ltd");
		md1.setOffer("10%");
		md1.setPrice("29");
		
		System.out.println(md1);
		

	}

}
