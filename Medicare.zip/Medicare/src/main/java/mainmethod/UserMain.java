package mainmethod;

import entity.User;

public class UserMain {

	public static void main(String[] args) {
		
		User u1 = new User();
		
		u1.setFirstname("John");
		u1.setLastname("Doe");
		u1.setEmail("john@gmail.com");
		u1.setMobno("456789123");
		u1.setPassword("456789");
		u1.setAddress(null);
		u1.setRole("user");
		u1.setGender("M");
		u1.setAge("39");
		
		
		System.out.println(u1);

	}

}
