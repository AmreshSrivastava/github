package exception;

public class CityNotFoundException extends Exception {

	public CityNotFoundException(String string) {
		super(string);
	}

}
