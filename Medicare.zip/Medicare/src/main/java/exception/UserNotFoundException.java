package exception;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String string) {
		super(string);
	}

	
}
