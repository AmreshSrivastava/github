package exception;

public class MedicineNotFoundException extends Exception {

	private void med() {
		System.out.println("Medicine not found");
	}
}
