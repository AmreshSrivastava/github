package exception;

public class DeliveryNotFoundException extends Exception {

	public DeliveryNotFoundException(String string) {
		super(string);
	}

}
