package repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import entity.User;

@Repository
public interface UserRepo extends JpaRepository<User, String>{

	void deleteByMobno(String mobno);

	Optional<User> findbyCompany(String mobno, String email);

	Optional<User> findAllByCity(String city);

}
