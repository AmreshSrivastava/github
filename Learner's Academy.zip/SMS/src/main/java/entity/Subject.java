package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Subject")
public class Subject {

	@Id
	private String standard;
	
	@Column(name="SubjectName")
	private String SubjectName;
	
	public Subject() {
		
	}

	public Subject(String standard, String subjectName) {
		super();
		this.standard = standard;
		this.SubjectName = subjectName;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getSubjectName() {
		return SubjectName;
	}

	public void setSubjectName(String subjectName) {
		this.SubjectName = subjectName;
	}
	
	
	
}
