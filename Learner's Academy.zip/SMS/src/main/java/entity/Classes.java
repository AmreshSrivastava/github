package entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Classes")

public class Classes {

	@Id
	private String standard;
	
	@Column(name="student")
	private Student student;
	
	@Column(name="subject")
	private Subject subject;
	
	@Column(name="teacher")
	private Teacher teacher;
	
	public Classes() {
		
	}

	public Classes(String standard, Student student, Subject subject, Teacher teacher) {
		super();
		this.standard = standard;
		this.student = student;
		this.subject = subject;
		this.teacher = teacher;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	
	
	
}
/*
 
class report  --- info about class --- 

list of student , list of subject , list of teacher

*/