package repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import entity.Teacher;

@Repository
public interface TeacherRepo  extends JpaRepository <Teacher , String>{

	//sql
			@Query(name="select * from teacher where s.standard=?1 and s.subjectname=?2" , nativeQuery= true)
			Optional<Teacher> findbyStandardAndSubjectName(String standard, String SubjectName);

}
