package repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import entity.Student;

@Repository
public interface StudentRepo extends JpaRepository <Student , String>{

	//jpql
	//@Query(name="select s from entity.Student s where s.standard = ?1 and s.phoneNo=?2")
	
	//sql
	@Query(name="select * from student where s.standard=?1 and s.phoneNo=?2" , nativeQuery= true)
	Optional<Student> findbyStandardAndPhoneNo(String standard, String phoneNo);

}
