package repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import entity.Subject;


@Repository
public interface SubjectRepo extends JpaRepository <Subject , String>{

	//sql
		@Query(name="select * from subject where s.standard=?1" , nativeQuery= true)
		Optional<Subject> findbyStandard(String standard);

		void deleteByStandardAndSubjectName(String standard, String subjectName);


}
