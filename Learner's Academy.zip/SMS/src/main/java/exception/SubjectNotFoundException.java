package exception;

public class SubjectNotFoundException extends Exception {

	public SubjectNotFoundException(String desc)
	{
		super(desc);
	}
}
