package exception;

public class StudentNotFoundException extends RuntimeException {

	public StudentNotFoundException(String desc)
	{
		super(desc);
	}
}
