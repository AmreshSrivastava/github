package exception;

public class TeacherNotFoundException extends Exception {

	public TeacherNotFoundException(String desc)
	{
		super(desc);
	}
}
