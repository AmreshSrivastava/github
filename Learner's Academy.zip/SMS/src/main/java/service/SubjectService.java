package service;

import java.util.List;

import org.springframework.stereotype.Component;

import entity.Subject;
import exception.SubjectNotFoundException;

@Component
public interface SubjectService {

	//crud operation
	
	Subject insert(String standard , String SubjectName);
	
	void update(String standard , String SubjectName);
	
	void delete(String standard , String SubjectName);
	
	List <Subject> getSubject();
	Subject getSubject(String standard) throws SubjectNotFoundException;
}
