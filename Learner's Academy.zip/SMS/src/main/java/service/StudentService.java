package service;

import java.util.List;

import org.springframework.stereotype.Component;

import entity.Student;
import exception.StudentNotFoundException;

@Component
public interface StudentService {

	//Crud operation
	
	Student insert(String id , String firstname , String lastname , 
			String address , String emailId , String standard ,
			String phoneNo ,String motherName , String fatherName);
	
	void update(String id , String firstname , String lastname , 
			String address , String emailId , String standard ,
			String phoneNo ,String motherName , String fatherName);
	
	void delete(String id);
	
	List <Student> getStudent(String standard);
	Student getStudent(String standard, String phoneNo) throws StudentNotFoundException;

}
