package service;

import java.util.List;

import org.springframework.stereotype.Component;

import entity.Teacher;
import exception.TeacherNotFoundException;

@Component
public interface TeacherService {

	//crud operation
	
	Teacher insert(String id , String firstname , String lastname ,
			String age ,String phoneNo ,String emailId ,
			String address ,String subject ,String standard);
	
	void update(String id , String firstname , String lastname ,
			String age ,String phoneNo ,String emailId ,
			String address ,String subject ,String standard);
	
	void delete(String id);
	
	List <Teacher> getTeacher();
	Teacher getTeacher(String standard, String SubjectName) throws TeacherNotFoundException;
	
}
