package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class Teachercontroller {

	@PostMapping("teacher")
	public String teacher()
	{
		return "teacher";
	}
}
