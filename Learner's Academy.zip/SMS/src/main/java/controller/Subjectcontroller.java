package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class Subjectcontroller {

	@PostMapping("subject")
	public String subject()
	{
		return "subject";
	}
}
