package controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Home {

	@RequestMapping("")
	public String home()
	{
		return "home";
	}
	
	@PostMapping("signup")
	public String signup()
	{
		return "signup";
	}
	
	@PostMapping("login")
	public String login()
	{
		return "login";
	}
}
