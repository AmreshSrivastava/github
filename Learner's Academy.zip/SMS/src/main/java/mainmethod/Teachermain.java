package mainmethod;

import entity.Teacher;

public class Teachermain {

	public static void main(String[] args) {
		
		Teacher t1 = new Teacher();
		t1.setId("1");
		t1.setFirstname("Archana");
		t1.setLastname("Saxena");
		t1.setAge("35");
		t1.setPhoneNo("213456789");
		t1.setEmailId("archana@gmail.com");
		t1.setAddress("Delhi");
		t1.setSubject("Biology");
		t1.setStandard("10");
		
		System.out.println("Id    " + "First name   " + "Last name    " + "Age     " + 
		"Phone no     " + "Email id     " + "Address     " + "Subject     " + 
				"Standard     ");
		
		System.out.println(t1.getId() + "    " + t1.getFirstname() + "         " + t1.getLastname()
		+ "    " + t1.getAge() + "    " + t1.getPhoneNo() + "    " + t1.getEmailId()
		+ "    " + t1.getAddress() + "    " + t1.getSubject() + "    " + t1.getStandard());

	}

}
