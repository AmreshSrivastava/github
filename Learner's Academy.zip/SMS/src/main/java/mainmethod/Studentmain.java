package mainmethod;

import entity.Student;

public class Studentmain {

	public static void main(String[] args) {
		
		Student s1 = new Student();
		s1.setId("1");
		s1.setFirstname("Amresh");
		s1.setLastname("Srivastava");
		s1.setAddress("Prayagraj");
		s1.setStandard("10");
		s1.setPhoneNo("123456789");
		s1.setEmailId("amresh@gmail.com");
		s1.setMotherName("Neelam Srivastava");
		s1.setFatherName("Vinod Kumar Srivastava");

		System.out.println("Id  " + "First name  "  + "Last name  " + "Address  " +
		 "Standard  " + "Phone no.  " +  "Email id   " +  "Mother name  "  + "Father name  ");
		
		
		System.out.println(s1.getId() + " " + s1.getFirstname() + " " +
		s1.getLastname() + " " + s1.getAddress() + " " + s1.getStandard() +
		" "+s1.getPhoneNo() +s1.getEmailId() + " " + s1.getMotherName() + " "
		+ s1.getFatherName());
		
	}

}
