package mainmethod;

import entity.Subject;

public class Subjectmain {

	public static void main(String[] args) {
		
		Subject sub1 = new Subject();
		sub1.setStandard("10");
		sub1.setSubjectName("Physics");
		
		System.out.println("Standard" + "   " + "Subject Name");
		System.out.println("   " + sub1.getStandard() + "          " + sub1.getSubjectName());

		
	}

}
