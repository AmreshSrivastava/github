package serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import entity.Subject;
import entity.Teacher;
import exception.SubjectNotFoundException;
import exception.TeacherNotFoundException;
import repository.TeacherRepo;
import service.TeacherService;

@Service("teacherservice")
public class TeacherserviceImpl implements TeacherService{

	private TeacherRepo teacherrepo;
	private TeacherService teacherservice;
	
	public TeacherserviceImpl(TeacherRepo teacherrepo, TeacherService teacherservice) {
		super();
		this.teacherrepo = teacherrepo;
		this.teacherservice = teacherservice;
	}

	@Override
	public Teacher insert(String id, String firstname, String lastname, String age, String phoneNo, String emailId,
			String address, String subject, String standard) {
		
		Teacher t1 = new Teacher();
		t1.setId(id);
		t1.setFirstname(firstname);
		t1.setLastname(lastname);
		t1.setAge(age);
		t1.setPhoneNo(phoneNo);
		t1.setEmailId(emailId);
		t1.setAddress(address);
		t1.setSubject(subject);
		t1.setStandard(standard);
		
		Teacher tea = teacherrepo.save(t1);
		return tea;
		
	}

	@Override
	public void update(String id, String firstname, String lastname, String age, String phoneNo, String emailId,
			String address, String subject, String standard) {
		
		Teacher t1 = new Teacher();
		t1.setId(id);
		t1.setFirstname(firstname);
		t1.setLastname(lastname);
		t1.setAge(age);
		t1.setPhoneNo(phoneNo);
		t1.setEmailId(emailId);
		t1.setAddress(address);
		t1.setSubject(subject);
		t1.setStandard(standard);
		
		Teacher t = teacherrepo.save(t1);
		
	}

	@Override
	public void delete(String id) {
		
		teacherrepo.deleteById(id);		
	}

	@Override
	public List<Teacher> getTeacher() {
		
		return teacherrepo.findAll();
	}

	@Override
	public Teacher getTeacher(String standard,String SubjectName) throws TeacherNotFoundException{
		Teacher t = null;
		Optional <Teacher> teacherOptional =  teacherrepo.findbyStandardAndSubjectName(standard, SubjectName);
		if(teacherOptional.isPresent()) {
			t=teacherOptional.get();
		}
		else
		{
			throw new TeacherNotFoundException("Teacher not found");
		}
		return t;
	}
}
