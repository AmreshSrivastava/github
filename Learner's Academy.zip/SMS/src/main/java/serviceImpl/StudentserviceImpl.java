package serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import entity.Student;
import exception.StudentNotFoundException;
import repository.StudentRepo;
import service.StudentService;

@Service("studentService")
public class StudentserviceImpl implements StudentService{

	private StudentRepo studentrepo;
	private StudentService  studentservice;


	public StudentserviceImpl(StudentRepo studentrepo, StudentService studentservice) {
		super();
		this.studentrepo = studentrepo;
		this.studentservice = studentservice;
	}

	@Override
	public Student insert(String id, String firstname, String lastname, String address, String emailId, String standard,
			String phoneNo, String motherName, String fatherName) {
		
		Student student =new Student();
		student.setId(id);
		student.setFirstname(firstname);
		student.setLastname(lastname);
		student.setAddress(address);
		student.setEmailId(emailId);
		student.setStandard(standard);
		student.setPhoneNo(phoneNo);
		student.setMotherName(motherName);
		student.setFatherName(fatherName);
		
		Student student1 = studentrepo.save(student);
		return student1;
		
	}

	@Override
	public void update(String id, String firstname, String lastname, String address, String emailId, String standard,
			String phoneNo, String motherName, String fatherName) {
		
		Student student =new Student();
		student.setId(id);
		student.setFirstname(firstname);
		student.setLastname(lastname);
		student.setAddress(address);
		student.setEmailId(emailId);
		student.setStandard(standard);
		student.setPhoneNo(phoneNo);
		student.setMotherName(motherName);
		student.setFatherName(fatherName);
		
		Student student1 = studentrepo.save(student);
		
		
		}

	@Override
	public void delete(String id) {
		studentrepo.deleteById(id);
		
	}

	@Override
	public List<Student> getStudent(String standard) {
		return studentrepo.findAll();
		 
	}

	@Override
	public Student getStudent(String standard, String phoneNo) throws StudentNotFoundException{
		Student s = null;
		Optional <Student> studentOptional =  studentrepo.findbyStandardAndPhoneNo(standard, phoneNo);
		if(studentOptional.isPresent()) {
			s=studentOptional.get();
		}
		else
		{
			throw new StudentNotFoundException("Student not found");
		}
		return s;
	}

}
