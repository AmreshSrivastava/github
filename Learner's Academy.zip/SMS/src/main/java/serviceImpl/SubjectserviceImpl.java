package serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import entity.Student;
import entity.Subject;
import exception.StudentNotFoundException;
import exception.SubjectNotFoundException;
import repository.SubjectRepo;
import service.SubjectService;

@Service("subjectservice")
public class SubjectserviceImpl implements SubjectService{

	private SubjectRepo subjectrepo;
	private SubjectService subjectservice;
	
	
	public SubjectserviceImpl(SubjectRepo subjectrepo, SubjectService subjectservice) {
		super();
		this.subjectrepo = subjectrepo;
		this.subjectservice = subjectservice;
	}

	@Override
	public Subject insert(String standard, String SubjectName) {
		
		Subject sub = new Subject();
		sub.setStandard(standard);
		sub.setSubjectName(SubjectName);
		
		Subject sub1 = subjectrepo.save(sub);
		return sub1;
		
	}

	@Override
	public void update(String standard, String SubjectName) {
		
		Subject sub = new Subject();
		sub.setStandard(standard);
		sub.setSubjectName(SubjectName);
		
		Subject sub1 = subjectrepo.save(sub);
	}

	@Override
	public void delete(String standard, String SubjectName) {
		subjectrepo.deleteByStandardAndSubjectName(standard,SubjectName);
		
	}

	@Override
	public List<Subject> getSubject() {
		
		return subjectrepo.findAll();
	}

	@Override
	public Subject getSubject(String standard) throws SubjectNotFoundException{
		Subject s = null;
		Optional <Subject> subjectOptional =  subjectrepo.findbyStandard(standard);
		if(subjectOptional.isPresent()) {
			s=subjectOptional.get();
		}
		else
		{
			throw new SubjectNotFoundException("Subject not found");
		}
		return s;
	}

}
