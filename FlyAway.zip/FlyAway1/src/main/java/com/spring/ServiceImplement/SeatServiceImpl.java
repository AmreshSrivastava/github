package com.spring.ServiceImplement;

import java.util.List;

import com.spring.Service.SeatService;
import com.spring.entity.Seat;
import com.spring.entity.SeatClass;

public class SeatServiceImpl implements SeatService{

	@Override
	public void insertSeat(SeatClass seatclass, String SeatId, boolean status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateSeat(SeatClass seatclass, String SeatId, boolean status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Seat> getSeat(SeatClass seatclass, boolean status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteSeat(SeatClass seatclass, String SeatId, boolean status) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Seat findAllSeatBySeatClassAndstatus(SeatClass seatclass, boolean status) {
		// TODO Auto-generated method stub
		return null;
	}

}
