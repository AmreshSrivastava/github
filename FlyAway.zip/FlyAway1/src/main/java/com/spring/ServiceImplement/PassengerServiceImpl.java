package com.spring.ServiceImplement;

import java.util.List;

import com.spring.Service.PassengerService;
import com.spring.entity.Address;
import com.spring.entity.Name;
import com.spring.entity.Passenger;

public class PassengerServiceImpl implements PassengerService{

	@Override
	public void insertPassenger(String PhoneNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addPassenger() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Passenger findAllPassengerByPhoneNumber(String PhoneNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updatePassenger(Name name, Address address, String PhoneNumber, String EmailId, String DoB) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletePassenger(String PhoneNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Passenger> getPassenger(String FlightNumber, String DepartureAirport, String DepartureDate,
			String DestinationAirport, String DestinationDate, String ArrivalTime) {
		// TODO Auto-generated method stub
		return null;
	}

}
