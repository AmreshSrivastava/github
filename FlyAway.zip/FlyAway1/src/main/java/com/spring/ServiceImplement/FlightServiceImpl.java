package com.spring.ServiceImplement;

import java.util.List;

import com.spring.Service.FlightService;
import com.spring.entity.Flight;

public class FlightServiceImpl implements FlightService{

	@Override
	public void insertFlight(String FlightNumber, String DepartureAirport, String DepartureDate, String DepartureTime,
			String DestinationAirport, String DestinationDate, String ArrivalTime) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateFlight(int FlightNumber, String DepartureAirport, String DepartureDate, String DepartureTime,
			String DestinationAirport, String DestinationDate, String ArrivalTime) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteFlightByFlightNumber(String FlightNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Flight> getFlight() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Flight getFlight(String FlightNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Flight findAllFlightByFlightNumber(String FlightNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Flight findAllFlightByDepartureAirportAndDestinationAirport(String DepartureAirport,
			String DestinationAirport) {
		// TODO Auto-generated method stub
		return null;
	}

}
