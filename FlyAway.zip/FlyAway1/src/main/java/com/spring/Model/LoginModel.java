package com.spring.Model;

public class LoginModel {

	private String username;
	private String Password;
	
	public LoginModel() {
		
	}

	public LoginModel(String username, String password) {
		super();
		this.username = username;
		this.Password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		this.Password = password;
	}
	
	
}
