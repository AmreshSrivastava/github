package com.spring.Model;

public class SeatModel {

}
