package com.spring.Model;

public class FlightModel {
 
	
}
