package com.spring.MainMethod;

import com.spring.entity.Name;

public class Namemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Name name1 = new Name();
		name1.setFirstName("Amresh");
		name1.setLastName("Srivastava");
		System.out.println(name1);
		
		Name name2 = new Name();
		name2.setFirstName("Ankita");
		name2.setLastName("Srivastava");
		System.out.println(name2);
	}

}
