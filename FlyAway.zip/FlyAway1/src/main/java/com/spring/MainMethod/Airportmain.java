package com.spring.MainMethod;

import com.spring.entity.Airport;

public class Airportmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Airport airport1 = new Airport();
		airport1.setAirportid("DEL");  //IATA code - DEL for Delhi 
		airport1.setAirportName(" Indira Gandhi International Airport");
		airport1.setCity("Delhi");
		airport1.setCountry("India");
		
		System.out.println(airport1);
		
		Airport airport2 = new Airport();
		airport2.setAirportid("BLR");
		airport2.setAirportName("Kempegowda International Airport");
		airport2.setCity("Bengaluru");
		airport2.setCountry("India");
		
		System.out.println(airport2);
		//System.out.println("\n" + airport2.getAirportid() + airport2.getAirportName() + airport2.getCity() + airport2.getCountry());

	}

}
