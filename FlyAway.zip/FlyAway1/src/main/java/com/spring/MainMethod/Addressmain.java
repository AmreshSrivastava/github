package com.spring.MainMethod;

import com.spring.entity.Address;

public class Addressmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Address address1 = new Address();
		address1.setHouseNumber("D12");
		address1.setLocality("IndiraNagar");
		address1.setCity("Banglore");
		address1.setState("Karnataka");
		address1.setCountry("India");
		System.out.println(address1);
		
		Address address2 = address1;
	}

}
