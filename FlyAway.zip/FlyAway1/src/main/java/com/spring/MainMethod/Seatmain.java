package com.spring.MainMethod;

import com.spring.entity.Seat;
import com.spring.entity.SeatClass;

public class Seatmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Seat seat1 = new Seat();
		seat1.setSeatclass(SeatClass.ECONOMY);
		seat1.setSeatid("D4");
		seat1.setStatus(true);
		System.out.println(seat1);
		
		Seat seat2 = new Seat();
		seat2.setSeatclass(SeatClass.ECONOMY);
		seat2.setSeatid("D5");
		seat2.setStatus(true);
		System.out.println(seat2);
		
	}

}
