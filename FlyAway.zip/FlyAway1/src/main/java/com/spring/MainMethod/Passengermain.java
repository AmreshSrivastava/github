package com.spring.MainMethod;

import com.spring.entity.Address;
import com.spring.entity.Name;
import com.spring.entity.Passenger;

public class Passengermain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Name name1 = new Name();
		Address address1 = new Address();
		
		Name name2 = new Name();
		Address address2 = new Address(); 
		
		Passenger passenger1 = new Passenger();
		passenger1.setName(name1);
		passenger1.setAddress(address1);
		passenger1.setPhoneNumber("123456789");
		passenger1.setEmailId("amresh123@gmail.com");
		passenger1.setDoB("05/10/1996");
		passenger1.setGender("M");
		
		Passenger passenger2 = new Passenger();
		passenger2.setName(name2);
		passenger2.setAddress(address2);
		passenger1.setPhoneNumber("123456789");
		passenger1.setEmailId("amresh123@gmail.com");
		passenger1.setDoB("30/09/2001");
		passenger1.setGender("F");
		
		System.out.println(passenger1 + "/n" + passenger2);
	}

}
