package com.spring.MainMethod;

import com.spring.entity.Address;
import com.spring.entity.Flight;
import com.spring.entity.Name;
import com.spring.entity.Passenger;
import com.spring.entity.Reservation;
import com.spring.entity.Seat;

public class Reservationmain {

	public static void main(String[] args) {

//		 ReservationNumber;
//		 NumberOfPassenger;
//		 Passenger [] passenger 
//		 FlightNumber;
//		 DepartureDate;
//		 ReservedSeat;
//		
		Seat seat1 = new Seat();
		Seat seat2 = new Seat();

		Name name1 = new Name();
		Address address1 = new Address();
		Passenger passenger1 = new Passenger();

		Name name2 = new Name();
		Address address2 = new Address();
		Passenger passenger2 = new Passenger();

		Passenger[] passenger = { passenger1, passenger2 };
		Seat[] ReservedSeat = { seat1, seat2 };

		Flight flight1 = new Flight();

		Reservation reservation1 = new Reservation(123);
		System.out.println(reservation1);

	}

}
