package com.spring.MainMethod;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

import com.spring.entity.Classes;

public class Splitmain {

	public static void main(String[] args) {
		
		String[] AirportDetail = new String[3];
		
		String test = "";
		String AirportID = "";
		String AirportCity = "";
		String AirportCountry = "";
		
		String[] AirlineDetail = new String[2];
		String AirlineID = "";
		String AirlineName = "";
		
		String [] FlightDetail = new String[6];
		String FlightNumber = "" ;
		String DepartureDate = "";
		String DepartureTime = "";
		String DepartureAirport = "";
		String DestinationAirport = "";
		String ArrivalTime = "";
		
//		
		try {
		Scanner sc = new Scanner(new FileInputStream("FlightInfo.txt"));
		PrintWriter pw = new PrintWriter(new FileOutputStream("SplitTest.txt"));
	
	    boolean end = false;
	    
	    pw.println("List of Airport");
	    
	    while(read.hasNextLine() && !end) {
	    	
	    	String text = read.nextLine();
	    	
	    	 if(text.compareTo("#") == 0){
	                while(!read.hasNext("#")){
	                    AirportDetail = read.nextLine().split(",");
	                    AirportID = AirportDetail[0];
	                    AirportCity = AirportDetail[1];
	                    AirportCountry = AirportDetail[2];
	                    
	                    pw.println(AirportID + "\t" + AirportCity + "\t" + AirportCountry);
	                }
	                end = true;
	                text = "";
	            }
	    	 
	    	 if(text.compareTo("**") == 0){
	                AirlineDetail = read.nextLine().split(",");
	               AirlineID = AirlineDetail[0];
	                AirlineName = AirlineDetail[1];
	                pw.println(AirlineID + "\t" + AirlineName);
	                
	                
	                
	                if(text.compareTo("*") == 0){
	                    FlightDetail = read.nextLine().split(",");
	                    FlightNumber = FlightDetail[0];
	                    DepartureDate = FlightDetail[1];
	                    DepartureAirport = FlightDetail[2];
	                    DestinationAirport = FlightDetail[3]; 
	                    DepartureTime = FlightDetail[4];
	                    ArrivalTime = FlightDetail[5];
	                    pw.println(FlightNumber + "\t" + DepartureDate + "\t" + DepartureAirport + "\t" + DestinationAirport + "\t" + DepartureTime + "\t" + ArrivalTime);
	                }      
	                
	                
	                boolean end = false;
	                
	                while(read.hasNextLine() && !end){
	                    String text = read.nextLine();
	                    
	                    if(text.compareTo("#") == 0){
	                        while(!read.hasNext("#")){                    
	                            String AirportInfo = read.nextLine();
	                            String[] AirportDet = AirportInfo.split(",");
	                            pw.println(AirportDet[0] + "\t" + AirportDet[1] + "/t" + AirportDet[2]);
	                        }
	                        end = true;
	                        line = "";
	                    }
	    	
	    }
	    catch(FileNotFoundException e) {
	    	System.out.println("Invalid");
	    }
	    catch(Exception e) {
	    	System.out.println("Exception");
	    }
	    
	    }
	
	}

}
