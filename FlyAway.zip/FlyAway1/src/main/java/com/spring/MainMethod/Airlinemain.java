package com.spring.MainMethod;

import com.spring.entity.Airline;

public class Airlinemain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Airline airline1 = new Airline();
		airline1.setAirlineid("6E");
		airline1.setAirlinename("Indigo");
		System.out.println(airline1);
		
		//The airline accounting code, or prefix code, is a 3-digit number,
		//referenced by IATA and unique among all the airlines, used to identify the airline 
		//in various accounting activities such as ticketing.
		
		//IATA airline designators, sometimes called IATA reservation codes, are two-character codes assigned by the
		//International Air Transport Association (IATA) to the world's airlines. 
	}

}
