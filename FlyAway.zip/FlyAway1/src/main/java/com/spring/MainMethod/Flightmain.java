package com.spring.MainMethod;

import com.spring.entity.Airline;
import com.spring.entity.Flight;

public class Flightmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Flight flight1 = new Flight();
		
		Airline airline1 = new Airline("6E" , "Indigo");
		
		//use angular for date/time format
		flight1.setFlightNumber("6612");
		flight1.setDepartureAirport("DEL , Delhi , Indira Gandhi International Airport , India");
		flight1.setDepartureDate();  
		flight1.setDepartureTime();
		flight1.setDestinationAirport("BLR , Bengaluru ,Kempegowda International Airport , India");
		flight1.setDestinationDate();
		flight1.setArrivalTime();
		
		System.out.println(flight1);
		
	}

}
