package com.spring.entity;

public class Classes {

	private SeatClass seatClass;  
	
	public Classes() {
		
	}

	public Classes(SeatClass seatClass) {
		super();
		this.seatClass = seatClass;
	}

	public SeatClass getSeatClass() {
		return seatClass;
	}

	public void setSeatClass(SeatClass seatClass) {
		this.seatClass = seatClass;
	}
	
	
}
