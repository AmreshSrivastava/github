package com.spring.entity;

public class Reservation {

	private int ReservationNumber;
	private int NumberOfPassenger;
	private Passenger [] passenger = new Passenger [NumberOfPassenger];
	private String FlightNumber;
	private String DepartureDate;
	private Seat[] ReservedSeat;
	
	public Reservation() {
		
	}

	public Reservation(int reservationNumber, int numberOfPassenger, Passenger[] passenger, String flightNumber,
			String departureDate, Seat[] reservedSeat) {
		super();
		this.ReservationNumber = reservationNumber;
		this.NumberOfPassenger = numberOfPassenger;
		this.passenger = passenger;
		this.FlightNumber = flightNumber;
		this.DepartureDate = departureDate;
		this.ReservedSeat = reservedSeat;
	}

	public int getReservationNumber() {
		return ReservationNumber;
	}

	public void setReservationNumber(int reservationNumber) {
		this.ReservationNumber = reservationNumber;
	}

	public int getNumberOfPassenger() {
		return NumberOfPassenger;
	}

	public void setNumberOfPassenger(int numberOfPassenger) {
		this.NumberOfPassenger = numberOfPassenger;
	}

	public Passenger[] getPassenger() {
		return passenger;
	}

	public void setPassenger(Passenger[] passenger) {
		this.passenger = passenger;
	}

	public String getFlightNumber() {
		return FlightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.FlightNumber = flightNumber;
	}

	public String getDepartureDate() {
		return DepartureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.DepartureDate = departureDate;
	}

	public Seat[] getReservedSeat() {
		return ReservedSeat;
	}

	public void setReservedSeat(Seat[] reservedSeat) {
		this.ReservedSeat = reservedSeat;
	}
	
	
	
	
}
