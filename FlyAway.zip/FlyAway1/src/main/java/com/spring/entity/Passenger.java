package com.spring.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Passenger {

	private Name name;
	private Address address;
	@Id
	private String PhoneNumber;
	private String EmailId;
	private String DoB;
	private String Gender;
	
	public Passenger() {
		
	}

	public Passenger(Name name, Address address, String phoneNumber, String emailId, String doB, String gender) {
		super();
		this.name = name;
		this.address = address;
		this.PhoneNumber = phoneNumber;
		this.EmailId = emailId;
		this.DoB = doB;
		this.Gender = gender;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.PhoneNumber = phoneNumber;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		this.EmailId = emailId;
	}

	public String getDoB() {
		return DoB;
	}

	public void setDoB(String doB) {
		this.DoB = doB;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		this.Gender = gender;
	}

	  @Override
	    public String toString() {
	        return name + "\n" + address + "\n" + PhoneNumber + 
	        		"\n" + EmailId + "\n" + DoB + "\n" + Gender ;
	    }
	  
}
