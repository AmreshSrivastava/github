package com.spring.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Seat {

	private SeatClass seatclass;
	@Id
	private String seatid;
	private boolean status;
	
	public Seat() {
		
	}

	public Seat(SeatClass seatclass, String seatid, boolean status) {
		super();
		this.seatclass = seatclass;
		this.seatid = seatid;
		this.status = status;
	}

	public SeatClass getSeatclass() {
		return seatclass;
	}

	public void setSeatclass(SeatClass seatclass) {
		this.seatclass = seatclass;
	}

	public String getSeatid() {
		return seatid;
	}

	public void setSeatid(String seatid) {
		this.seatid = seatid;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	
}