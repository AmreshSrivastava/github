package com.spring.entity;

public enum SeatClass {

	FIRST,
	BUSINESS,
	ECONOMY
}
