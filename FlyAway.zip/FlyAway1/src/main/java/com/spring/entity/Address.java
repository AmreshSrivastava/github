package com.spring.entity;

public class Address {

	private String HouseNumber;
	private String Locality;
	private String City;
	private String State;
	private String Country;
	
	public Address() {
		
	}

	public Address(String houseNumber, String locality, String city, String state, String country) {
		super();
		this.HouseNumber = houseNumber;
		this.Locality = locality;
		this.City = city;
		this.State = state;
		this.Country = country;
	}

	public String getHouseNumber() {
		return HouseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.HouseNumber = houseNumber;
	}

	public String getLocality() {
		return Locality;
	}

	public void setLocality(String locality) {
		this.Locality = locality;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		this.City = city;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		this.State = state;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		this.Country = country;
	}
	
	
}
