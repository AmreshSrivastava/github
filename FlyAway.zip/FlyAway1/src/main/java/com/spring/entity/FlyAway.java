package com.spring.entity;

public class FlyAway {

	private String detail;
	private Airport [] airport;
	private Airline [] airline;
	private Flight [] flight;
	private Seat [][] seat;
	private Reservation [] reservation = new Reservation[240];
	
	
	public FlyAway() {
		
	}


	public FlyAway(String detail, Airport[] airport, Airline[] airline, Flight[] flight, Seat[][] seat,
			Reservation[] reservation) {
		super();
		this.detail = detail;
		this.airport = airport;
		this.airline = airline;
		this.flight = flight;
		this.seat = seat;
		this.reservation = reservation;
	}


	public String getDetail() {
		return detail;
	}


	public void setDetail(String detail) {
		this.detail = detail;
	}


	public Airport[] getAirport() {
		return airport;
	}


	public void setAirport(Airport[] airport) {
		this.airport = airport;
	}


	public Airline[] getAirline() {
		return airline;
	}


	public void setAirline(Airline[] airline) {
		this.airline = airline;
	}


	public Flight[] getFlight() {
		return flight;
	}


	public void setFlight(Flight[] flight) {
		this.flight = flight;
	}


	public Seat[][] getSeat() {
		return seat;
	}


	public void setSeat(Seat[][] seat) {
		this.seat = seat;
	}


	public Reservation[] getReservation() {
		return reservation;
	}


	public void setReservation(Reservation[] reservation) {
		this.reservation = reservation;
	}
	
	
}
