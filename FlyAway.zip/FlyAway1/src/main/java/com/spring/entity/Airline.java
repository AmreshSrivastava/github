package com.spring.entity;

public class Airline {

	private String airlineid;
	private String airlinename;
	
	public Airline() {
		
	}

	public Airline(String airlineid, String airlinename) {
		super();
		this.airlineid = airlineid;
		this.airlinename = airlinename;
	}

	public String getAirlineid() {
		return airlineid;
	}

	public void setAirlineid(String airlineid) {
		this.airlineid = airlineid;
	}

	public String getAirlinename() {
		return airlinename;
	}

	public void setAirlinename(String airlinename) {
		this.airlinename = airlinename;
	}

	
	
}
