package com.spring.entity;

public class Airport {

	private String airportid;
	private String airportName;
	private String city;
	private String country;
	
	public Airport() {
		
	}

	public Airport(String airportid, String airportName, String city, String country) {
		super();
		this.airportid = airportid;
		this.airportName = airportName;
		this.city = city;
		this.country = country;
	}

	public String getAirportid() {
		return airportid;
	}

	public void setAirportid(String airportid) {
		this.airportid = airportid;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	
	
}
