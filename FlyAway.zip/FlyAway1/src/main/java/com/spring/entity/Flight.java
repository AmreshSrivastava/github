package com.spring.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Flight {

	@Id
	private String FlightNumber;
	private String DepartureDate;
	private String DepartureTime;
	private String DestinationDate;
	private String ArrivalTime;
	private String DepartureAirport;
	private String DestinationAirport;
	private Classes[] classes;
	
	public Flight() {
		
	}

	public Flight(String flightNumber, String departureDate, String departureTime, String destinationDate,
			String arrivalTime, String departureAirport, String destinationAirport, Classes[] classes) {
		super();
		this.FlightNumber = flightNumber;
		this.DepartureDate = departureDate;
		this.DepartureTime = departureTime;
		this.DestinationDate = destinationDate;
		this.ArrivalTime = arrivalTime;
		this.DepartureAirport = departureAirport;
		this.DestinationAirport = destinationAirport;
		this.classes = classes;
	}

	public String getFlightNumber() {
		return FlightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.FlightNumber = flightNumber;
	}

	public String getDepartureDate() {
		return DepartureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.DepartureDate = departureDate;
	}

	public String getDepartureTime() {
		return DepartureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.DepartureTime = departureTime;
	}

	public String getDestinationDate() {
		return DestinationDate;
	}

	public void setDestinationDate(String destinationDate) {
		this.DestinationDate = destinationDate;
	}

	public String getArrivalTime() {
		return ArrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.ArrivalTime = arrivalTime;
	}

	public String getDepartureAirport() {
		return DepartureAirport;
	}

	public void setDepartureAirport(String departureAirport) {
		this.DepartureAirport = departureAirport;
	}

	public String getDestinationAirport() {
		return DestinationAirport;
	}

	public void setDestinationAirport(String destinationAirport) {
		this.DestinationAirport = destinationAirport;
	}

	public Classes[] getClasses() {
		return classes;
	}

	public void setClasses(Classes[] classes) {
		this.classes = classes;
	}

}