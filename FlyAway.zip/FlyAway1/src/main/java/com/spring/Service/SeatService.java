package com.spring.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.spring.entity.Seat;
import com.spring.entity.SeatClass;


@Component
public interface SeatService {

	void insertSeat(SeatClass seatclass, String SeatId ,boolean status);
	
	void updateSeat (SeatClass seatclass, String SeatId ,boolean status);
	
	List <Seat> getSeat(SeatClass seatclass ,boolean status );
	
	void deleteSeat (SeatClass seatclass, String SeatId ,boolean status);
	
	Seat findAllSeatBySeatClassAndstatus(SeatClass seatclass ,boolean status );
}
