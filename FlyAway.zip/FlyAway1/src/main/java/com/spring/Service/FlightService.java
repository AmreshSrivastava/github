package com.spring.Service;


import java.util.List;

import org.springframework.stereotype.Component;


import com.spring.entity.Flight;

@Component
public interface FlightService {

	void insertFlight(String FlightNumber , String DepartureAirport , String DepartureDate , String DepartureTime ,
			String DestinationAirport , String DestinationDate , String ArrivalTime);
	
	void updateFlight(int FlightNumber ,  String DepartureAirport , String DepartureDate , String DepartureTime ,
			String DestinationAirport , String DestinationDate , String ArrivalTime);
	
	void deleteFlightByFlightNumber (String FlightNumber);
	
	List <Flight> getFlight();
	
	Flight getFlight(String FlightNumber);
	
	Flight findAllFlightByFlightNumber (String FlightNumber);
	
	Flight findAllFlightByDepartureAirportAndDestinationAirport (String DepartureAirport , String DestinationAirport);
	
}
