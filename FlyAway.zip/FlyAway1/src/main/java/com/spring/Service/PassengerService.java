package com.spring.Service;

import java.util.List;

import org.springframework.stereotype.Component;


import com.spring.entity.Address;
import com.spring.entity.Name;
import com.spring.entity.Passenger;

@Component
public interface PassengerService {

	void insertPassenger(String PhoneNumber);
	
	void addPassenger ();
	
	Passenger findAllPassengerByPhoneNumber (String PhoneNumber);
	
	void updatePassenger (Name name , Address address , String PhoneNumber , String EmailId , String DoB);
	
	void deletePassenger (String PhoneNumber);
	
	List <Passenger> getPassenger (String FlightNumber , String DepartureAirport , String DepartureDate ,
			String DestinationAirport , String DestinationDate , String ArrivalTime);
	
	
	
	
}
